//
//  worldcupApp.swift
//  worldcup
//
//  Created by MELANY PAOLA RIVERA LORES on 12/10/25.
//

import SwiftUI

@main
struct worldcupApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
